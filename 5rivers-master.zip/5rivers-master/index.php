<?php
session_start();
?>
<?php  include('partial/head.php'); ?>

    <!-- Main content -->
    <section class="content container-fluid">

      <!--------------------------
        | Your Page Content Here |
        -------------------------->

    </section>
    <!-- /.content -->

<?php include('partial/foot.php'); ?>