  </div>
  <!-- /.content-wrapper -->

  <!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
      Powered by <a href="http://www.cubosquare.com/" target="_blank">Cubosquare IT Systems & Solutions</a>
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; <?php echo date('Y'); ?> <a href="#">5RIVERS ENTERTAINMENT ETC</a>.</strong> All rights reserved.
  </footer>
